# Write your solution here
#function to produce a pyramid of * chars and then add a * on a new line, we will then tweak that new line after proof of concept
def line(rows,amount,string):
    space = rows
    if string == '':
        print('*'*amount)
    else:
        print(f'{" "*int(space-1)}{string[0] *amount}')
        

def spruce(rows):
    print('a spruce!')
    count = 1
    pines = 1
    space = rows
    while count <= rows:
        
        line(space,pines,'*')
        pines += 2
        count += 1
        space -=1
    print(f'{" "*int(rows-1)}*')


    
# You can test your function by calling it within the following block
if __name__ == "__main__":
    spruce(4)