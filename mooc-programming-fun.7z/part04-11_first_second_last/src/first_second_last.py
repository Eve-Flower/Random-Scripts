# Write your solution here

def first_word(sentence):
    index = 0
    while True:
        if sentence[index] == ' ' and sentence[index -1] != ' ':
            first_word = sentence[0:index]
            return first_word
        index +=1
def second_word(sentence):
    index = sentence.find(' ')
    sentence = sentence[index + 1:]
    if sentence.find(' ') == -1:
        return sentence
    new_index = sentence.find(' ')
    return sentence[:new_index]

def last_word(sentence):
    index = -1
    while True:
        if sentence[index] == " ":
            index -= 1
        else:
            break
    while True:
        if sentence[index] != ' ':
                index -=1

        elif sentence[index == ' ']:
            return(sentence[index+1:])

    

    



    
# You can test your function by calling it within the following block
if __name__ == "__main__":
    sentence = "first second"
    print(first_word(sentence))
    print(second_word(sentence))
    print(last_word(sentence))