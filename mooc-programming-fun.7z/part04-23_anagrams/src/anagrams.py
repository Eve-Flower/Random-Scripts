# Write your solution here
def anagrams(string_1,string_2):
    return sorted(string_1) == sorted(string_2)
    