# Copy here code of line function from previous exercise and use it in your solution
def line(amount,string):
    if string == '':
        print('*'*amount)
    else:
        print(string[0] *amount)

def box_of_hashes(tri_size,rect_amount,rect_char):
    # You should call function line here with proper parameters
    count = 0
    while count < rect_amount:
        line(tri_size,rect_char)
        count +=1

def triangle(size,char):
    # You should call function line here with proper parameters
    count = 0
    while count <= size:
        line(count, char)
        count +=1

def shape(tri_size,tri_char,rect_amount,rect_char):
    triangle(tri_size,tri_char)
    box_of_hashes(tri_size,rect_amount,rect_char)
# You can test your function by calling it within the following block
if __name__ == "__main__":
    shape(5, "x", 3, "o")
    