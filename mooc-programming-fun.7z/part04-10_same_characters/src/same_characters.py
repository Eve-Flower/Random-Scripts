# Write your solution here
def same_chars(string, char_1, char_2):
    
    
    if char_1 >= len(string) or char_2 >= len(string):
        
        return False
    elif string[char_1] == string[char_2]:
        return True
    else: 
        return False
    
# You can test your function by calling it within the following block
if __name__ == "__main__":
    print(same_chars("abc", 0, 3))