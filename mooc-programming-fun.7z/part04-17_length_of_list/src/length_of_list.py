# Write your solution here
def length(list: list):
    
    return len(list)
# You can test your function by calling it within the following block
if __name__ == "__main__":
    my_list = [3, 6, -4]
    result = length(my_list)
    print(f'the length is {result}')