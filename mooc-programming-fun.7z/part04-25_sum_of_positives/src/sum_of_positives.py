# Write your solution here
def sum_of_positives(list:list):
    sum = 0
    for num in list:
        if num > 0:
            sum += num
    return sum

if __name__ == '__main__':
    sum_of_positives(list)