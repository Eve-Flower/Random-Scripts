# Write your solution here
def longest_series_of_neighbours(list:list):
    neighbours = 0
    current_number = list[0]
    most_neighbours = []
    for number in list:
        if abs(number - current_number) == 1:
            neighbours +=1
        elif abs(number - current_number) != 1:
            most_neighbours.append(neighbours)
            neighbours = 1
        current_number = number
    most_neighbours.append(neighbours)
    highest = max(most_neighbours)
    return highest

if __name__ == '__main__':
    my_list = [0,4,2,3,3,4,5]
    print(longest_series_of_neighbours(my_list))