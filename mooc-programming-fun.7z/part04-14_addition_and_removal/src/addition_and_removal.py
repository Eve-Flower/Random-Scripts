# Write your solution here
elements = []
count = 1
print(f'The list is now {elements}')
while True:
    choice = input('a(d)d, (r)emove or e(x)it: ')
    if choice == 'x':
        print('Bye!')
        break
    elif choice == 'd':
        elements.append(count)
        print(f'The list is now {elements}')
        count+=1
    elif choice == 'r':
        elements.pop()
        print(f'The list is now {elements}')
        count -=1