# Write your solution here
#first we need to get the user to input scores and split them in categories of exam points and exercise points

exam_points = []
exercise_list = []
sum = []
fail_included = []


while True:
    student_data = input('Exam points and exercises completed: ')
    if student_data == '':
        break
    index = student_data.find(' ')
    exam_points.append(int(student_data[0:index]))
    exercise_points = int(student_data[index+1:]) // 10
    exercise_list.append(exercise_points) 

def get_average(exam_points,exercise_list):
    
    #get average points:
    
    count = 0
    average = 0
    #but first, lets make our job easier by making a new list that has total points set to zero if we have exam_points less than 10
    for exam_point in exam_points:
        sum.append(exercise_list[count] + exam_point)
        count+=1
    for total in sum:
        average += total
    final_average = average/len(sum)
    return final_average

def get_pass_percentage(total_points):
    passed = 0
    for student_grade in total_points:
        if student_grade >=15:
            passed +=1
    return float((passed/len(total_points)) * 100)

def grade_distribution(total_points):
    
    grade =[0,0,0,0,0,0]

    for student_grade in total_points:
        if student_grade <=14:
            grade[0] += 1
        elif student_grade <=17:
            grade[1] += 1
        elif student_grade <=20:
            grade[2] += 1
        elif student_grade <=23:
            grade[3] += 1
        elif student_grade <=27:
            grade[4] += 1
        elif student_grade <=30:
            grade[5] += 1

    return grade

def failed_list(sum):
    count = 0
    failed_list = sum
    for number in sum:
        if (number-exercise_list[count]) < 10:
            failed_list[count] = 0
        count +=1
    return failed_list
def main():
    print('Statistics: ')
    print(f'Points average: {get_average(exam_points,exercise_list)}')
    percentage = str(get_pass_percentage(failed_list(sum))).split('.')
    if len(percentage[1]) > 2:
        print(f'Pass percentage: {get_pass_percentage(failed_list(sum)):.1f}')
    else:
        print(f'Pass percentage: {get_pass_percentage(failed_list(sum))}')
    
    print('Grade distribution: ')
    for i in range(0,6,1):
        print(f'  {5-i}: {grade_distribution(failed_list(sum))[5-i]*"*"}')

main()
 
    