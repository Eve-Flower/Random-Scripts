# Write your solution here
items = int(input('How many items: '))
count = 1
item_list = []
while count <= items:
    new_item = int(input(f'item {count}:'))
    item_list.append(new_item)
    count+=1
print(item_list)