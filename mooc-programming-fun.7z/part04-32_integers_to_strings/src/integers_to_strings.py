# Write your solution here
def formatted(list:list):
    new_list = []
    for item in list:
        item = (f'{item:.2f}')
        new_list.append(item)
      
    return new_list
if __name__ == "__main__":
    print(formatted([1.42,432.4,2.3333]))