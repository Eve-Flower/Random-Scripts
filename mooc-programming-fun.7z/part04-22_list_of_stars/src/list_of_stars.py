# Write your solution here
def list_of_stars(list:list):
    for item in list:
        print(item*'*')

if __name__ == '__main__':
    list_of_stars(list)