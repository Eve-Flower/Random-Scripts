# Write your solution here
def line(amount,string):
    if string == '':
        print('*'*amount)
    else:
        print(string[0] *amount)
# You can test your function by calling it within the following block
if __name__ == "__main__":
    line(5, "x")