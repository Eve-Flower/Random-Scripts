# Write your solution here
def most_common_character(string:str):
    #we need to count the appearance amount of each character in the string
    most_common = 0
    common_list = ''
    for character in string:
        if character != " ":
            if string.count(character) > most_common:
                most_common = string.count(character)
                common_list = character
            elif string.count(character) == most_common:
                if character not in common_list:
                    common_list += character
    return common_list[0]
    

            


    
        
    
if __name__ == "__main__":
    print(most_common_character('hi how are you'))