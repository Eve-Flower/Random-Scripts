# Write your solution here
def palindromes(string):
    return list(string) == list(reversed(string))
            

# Note, that at this time the main program should not be written inside
# if __name__ == "__main__":
# block!

while True:
    string = input('Please type in a palindrome: ')
    evaluation = palindromes(string)
    if evaluation == True:
        break
    print('that wasn\'t a palindrome')
print(f'{string} is a palindrome!')

    

    
    

