# Write your solution here
def no_vowels(string:str):
    vowels = ['a','e','i','o','u']
    new_string = ''
    count = 0
    while True:
        if count == len(string) or len(new_string) == len(string):
            break
        if string[count] in vowels:
            new_string += ''
        elif string[count] not in vowels:
            new_string+= string[count]
            
        #elif string[count] not in vowels: 
            #new_string += string[count]
            #print('new_string else:',new_string)   
         
        count +=1
    return new_string


if __name__ == '__main__':
    my_string = 'vowel'
    print(no_vowels(my_string))