# Write your solution here
def shortest(list:list)->str:
    current_word = list[0]
    for word in list:
        if len(word) < len(current_word):
            current_word = word
    return current_word

if __name__ == '__main__':
    my_list = ["adele", "mark", "doroth444y", "tim", "hedy", "richard"]
    print(shortest(my_list))