# Write your solution here

word_list = []
count = 0
while True:
    word = input('Word: ')
    
    if word in word_list:
        print(f'You typed in {count} different words')
        break
    count += 1
    word_list.append(word)
    

