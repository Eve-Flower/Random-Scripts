# Write your solution here

def even_numbers(list:list):
    new_list = []
    for num in list:
        if num % 2 ==0:
            new_list.append(num)
    
    return new_list

if __name__ == '__main__':
    evens_list = even_numbers(list)
    print("original", list)
    print("new", evens_list)