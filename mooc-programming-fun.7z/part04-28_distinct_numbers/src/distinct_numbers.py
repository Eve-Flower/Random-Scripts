# Write your solution here
def distinct_numbers(list:list)->list:
    my_list = []
    for num in list:
        if num not in my_list:
            my_list.append(num)
    return sorted(my_list)
if __name__ == '__main__':
    new_list = distinct_numbers([1,3,3,5])
    print(new_list)

            