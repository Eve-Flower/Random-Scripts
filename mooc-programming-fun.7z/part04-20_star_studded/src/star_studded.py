# Write your solution here
string = input('Please type in a string: ')
for letter in string:
    print(letter)
    print('*')
    