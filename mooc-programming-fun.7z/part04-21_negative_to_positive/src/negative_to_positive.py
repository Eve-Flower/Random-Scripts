string = input('enter a string: ')
print(list(string))
print(list(reversed(string)))