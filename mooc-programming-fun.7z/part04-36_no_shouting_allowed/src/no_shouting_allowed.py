# Write your solution here
def no_shouting(list:list):
    new_list = []
    for string in list:
        if string.isupper() != True:
            new_list.append(string)
       


    return new_list

if __name__ == '__main__':
    my_list = ['ABC','xYz', 'yxz','YXZ','Yxz']
    print(no_shouting(['FIRST', 'SECOND', 'third', 'fourth', 'fifth']))