# Write your solution here
def all_the_longest(list:list):
    current_word = ''
    longest_list =[]
    for word in list:
        if len(word) > len(current_word):
            current_word = word
    longest_list.append(current_word)
    for word in list:
        if len(word) == len(current_word) and word != current_word:
            longest_list.append(word)
    return longest_list


if __name__ == '__main__':
    my_list = ["adele", "mark", "doroth444y", "tim", "hedy", "richard"]
    print(all_the_longest(my_list))               