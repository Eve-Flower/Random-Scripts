# Write your solution here
def list_sum(list_1,list_2):
    count = 0
    for num in list_1:
        list_2[count] += num
        count +=1
    return list_2

if __name__ == '__main__':
    a = [1, 2, 3]
    b = [7, 8, 9]
    print(list_sum(a,b))