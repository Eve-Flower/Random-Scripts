# Write your solution here
def everything_reversed(list:list):
    reversed_list = reversed(list)
    new_list = []
    list_index = 0
    for item in reversed_list:
        new_list.append(item)
    for word in new_list:
        index = -1
        empty = ''
        while len(word) > len(empty):
            empty += word[index]

            index -= 1
            
        new_list[list_index] = empty
        list_index += 1

    return new_list

if __name__ == "__main__":
    my_list = ['ahri','xayah','942jjs']
    print(everything_reversed(my_list))